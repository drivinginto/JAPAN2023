# ✨MCCSC Salary Spread 2019-2020 👩‍🏫



#### This directory was created to:
* practice creating graphs in Python's Plotly library.
* to create a rough website on Github using a free Bootstrap template.

#### The data for the Plotly graphs come from MCCSC's (Monroe County Community School Corporation) [budget website](https://www.mccsc.edu//cms/lib/IN01906545/Centricity/Domain/51/AFR%20-%20CY%202019%20-%20MCCSC.pdf).<br> </br>
The graphs provide a visual for the spread and nature of employee salaries and experience. <br> </br>

![Salary Spread Example](Salary_Spread_2019.png)
